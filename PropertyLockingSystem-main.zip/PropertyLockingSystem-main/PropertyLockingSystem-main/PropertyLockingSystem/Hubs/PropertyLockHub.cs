﻿using Microsoft.AspNetCore.SignalR;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading.Tasks;

namespace PropertyLockingSystem.Hubs
{
    public class PropertyLockHub : Hub
    {
        private static readonly ConcurrentDictionary<string, string> PropertyLocks = new();

        public async Task LockProperty(string propertyId, string userName)
        {
            // TryAdd is atomic; prevents race condition from non-atomic ContainsKey + Add combo
            if (PropertyLocks.TryAdd(propertyId, Context.ConnectionId))
            {
                await Clients.Caller.SendAsync("LockAcquired", propertyId);
                await Clients.Others.SendAsync("PropertyLocked", propertyId, userName);
            }
            else
            {
                await Clients.Caller.SendAsync("LockDenied", propertyId);
            }
        }

        public async Task UnlockProperty(string propertyId)
        {
            // Ensure only the locker can unlock
            if (PropertyLocks.TryGetValue(propertyId, out var connectionId) && connectionId == Context.ConnectionId)
            {
                if (PropertyLocks.TryRemove(propertyId, out _))
                {
                    await Clients.All.SendAsync("PropertyUnlocked", propertyId);
                }
            }
            else
            {
                // Optionally notify client: not authorized to unlock
                await Clients.Caller.SendAsync("UnlockDenied", propertyId);
            }
        }

        public override async Task OnDisconnectedAsync(System.Exception? exception)
        {
            var lockedProperties = PropertyLocks
                .Where(x => x.Value == Context.ConnectionId)
                .Select(x => x.Key)
                .ToList();

            foreach (var propertyId in lockedProperties)
            {
                PropertyLocks.TryRemove(propertyId, out _);
                await Clients.All.SendAsync("PropertyUnlocked", propertyId);
            }

            await base.OnDisconnectedAsync(exception);
        }
    }
}
